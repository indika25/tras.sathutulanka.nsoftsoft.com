<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

  <!-- Sidebar Toggle (Topbar) -->
  <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
      <i class="fa fa-bars"></i>
  </button>

  <!-- Page Title -->
 <h4 class="d-none d-sm-inline-block text-dark font-weight-bold my-2" style="font-family: 'Arial', sans-serif;">
  
</h4>


  <!-- Spacer to push date/time right -->
  <div class="ml-auto">
    <span id="liveDateTime" class="text-muted font-weight-bold"></span>
  </div>

</nav>
